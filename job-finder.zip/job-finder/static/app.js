const DEFAULT_POS = [17.385, 78.4867]; // fallback: Hyderabad
const map = L.map("map").setView(DEFAULT_POS, 13);
L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
  maxZoom: 19,
  attribution: "&copy; OpenStreetMap contributors",
}).addTo(map);

const statusEl = document.getElementById("status");
const listEl = document.getElementById("placeList");
const panelEl = document.getElementById("jobsPanel");
const radiusEl = document.getElementById("radius");

let userMarker = null;
let userPos = DEFAULT_POS;
let markers = [];

function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text !== undefined) n.textContent = text;
  return n;
}

function setUser(lat, lng, note) {
  userPos = [lat, lng];
  if (!userMarker) {
    userMarker = L.marker(userPos, { draggable: true, title: "You are here" }).addTo(map);
    userMarker.on("dragend", () => {
      const p = userMarker.getLatLng();
      setUser(p.lat, p.lng, "Location set manually (drag the pin to change)");
    });
  } else {
    userMarker.setLatLng(userPos);
  }
  userMarker.bindTooltip("You are here (drag to change)");
  statusEl.textContent = note;
  loadPlaces();
}

async function loadPlaces() {
  const res = await fetch(`/api/places?lat=${userPos[0]}&lng=${userPos[1]}&radius_km=${radiusEl.value}`);
  const places = await res.json();

  markers.forEach((m) => m.remove());
  markers = [];
  listEl.innerHTML = "";
  panelEl.classList.add("hidden");

  if (!places.length) {
    listEl.appendChild(el("li", "meta", "No jobs found within this radius."));
    return;
  }

  places.forEach((p) => {
    const li = el("li");
    const marker = L.marker([p.lat, p.lng]).addTo(map);
    marker.bindTooltip(`${p.name} (${p.job_count})`);
    marker.on("click", () => showJobs(p.id, li));
    markers.push(marker);

    const left = el("div");
    left.appendChild(el("strong", "", p.name));
    left.appendChild(el("div", "meta", `${p.distance_km} km away`));
    li.appendChild(left);
    li.appendChild(el("span", "badge", `${p.job_count} job${p.job_count > 1 ? "s" : ""}`));
    li.addEventListener("click", () => {
      map.setView([p.lat, p.lng], 16);
      showJobs(p.id, li);
    });
    listEl.appendChild(li);
  });
}

async function showJobs(placeId, li) {
  document.querySelectorAll(".list li").forEach((x) => x.classList.remove("active"));
  if (li) li.classList.add("active");

  const res = await fetch(`/api/places/${placeId}/jobs`);
  const data = await res.json();
  panelEl.innerHTML = "";
  panelEl.classList.remove("hidden");
  panelEl.appendChild(el("h2", "", `Jobs at ${data.place.name}`));

  data.jobs.forEach((j) => {
    const card = el("div", "job");
    card.appendChild(el("h3", "", j.title));
    if (j.description) card.appendChild(el("p", "", j.description));
    if (j.apply_link) {
      const a = el("a", "", "Apply →");
      a.href = j.apply_link;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      card.appendChild(a);
    }
    panelEl.appendChild(card);
  });
  panelEl.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

radiusEl.addEventListener("change", loadPlaces);

if ("geolocation" in navigator) {
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      map.setView([pos.coords.latitude, pos.coords.longitude], 15);
      setUser(pos.coords.latitude, pos.coords.longitude, "Showing jobs near your current location");
    },
    () => setUser(DEFAULT_POS[0], DEFAULT_POS[1], "Location blocked – drag the pin to where you are"),
    { enableHighAccuracy: true, timeout: 8000 }
  );
} else {
  setUser(DEFAULT_POS[0], DEFAULT_POS[1], "Geolocation not supported – drag the pin to where you are");
}
